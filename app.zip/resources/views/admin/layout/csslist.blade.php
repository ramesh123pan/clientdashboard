@yield('css')
<!-- preloader css -->
<link rel="stylesheet" href="{{asset('vxtheme/assets/css/preloader.min.css')}}" type="text/css" />
<!-- Bootstrap Css -->
<link href="{{asset('vxtheme/assets/css/bootstrap.min.css')}}" id="bootstrap-style')}}" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="{{asset('vxtheme/assets/css/icons.min.css')}}" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="{{asset('vxtheme/assets/css/app.min.css')}}" id="app-style" rel="stylesheet" type="text/css" />