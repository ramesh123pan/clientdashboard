<script src="{{asset('vxtheme/assets/libs/jquery/jquery.min.js')}}"></script>
<script src="{{asset('vxtheme/assets/libs/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('vxtheme/assets/libs/metismenu/metisMenu.min.js')}}"></script>
<script src="{{asset('vxtheme/assets/libs/simplebar/simplebar.min.js')}}"></script>
<script src="{{asset('vxtheme/assets/libs/node-waves/waves.min.js')}}"></script>
<script src="{{asset('vxtheme/assets/libs/feather-icons/feather.min.js')}}"></script>
<!-- pace js -->
<script src="{{asset('vxtheme/assets/libs/pace-js/pace.min.js')}}"></script>
@yield('js')
<script src="{{asset('vxtheme/assets/js/app.js')}}"></script>